#!/system/bin/sh
# Wait for boot to complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done
sleep 5
# Set display saturation via SurfaceFlinger
service call SurfaceFlinger 1022 f 1.1
